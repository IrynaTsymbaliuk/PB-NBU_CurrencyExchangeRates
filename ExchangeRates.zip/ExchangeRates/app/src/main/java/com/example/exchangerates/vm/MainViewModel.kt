/*
package com.example.exchangerates.vm

import android.app.DatePickerDialog
import android.graphics.Paint
import android.os.Bundle
import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.DatePicker
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.*
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.exchangerates.R
import com.example.exchangerates.datasource.ExchangeRatesRepository
import com.example.exchangerates.model.NbuExchangeRatesResponse
import com.example.exchangerates.model.PbExchangeRatesResponse
import com.example.exchangerates.utils.PBListOfCurrenciesAdapter
import kotlinx.android.synthetic.main.pb_fr.*
import kotlinx.android.synthetic.main.pb_fr.view.*
import kotlinx.android.synthetic.main.pb_fr.view.pb_date_title
import java.text.SimpleDateFormat
import java.util.*

*/
/*
class PbFragment : Fragment(), View.OnClickListener, DatePickerDialog.OnDateSetListener {
    override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
        val calendar = Calendar.getInstance()
        calendar.set(year, month, dayOfMonth)
        val pickedDate = calendar.timeInMillis
        mainVM.setDateOfRates(pickedDate)
        onDateChange(pickedDate)
    }

    override fun onClick(v: View?) {
        showDatePicker()
    }

    private lateinit var mainVM: MainVM
    private lateinit var recyclerView: RecyclerView
    private lateinit var dateTittle: TextView
    private lateinit var dateIcon: ImageView
    private lateinit var pbRvAdapter: PBListOfCurrenciesAdapter
    private val formatter = SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mainVM = ViewModelProviders.of(this).get(MainVM::class.java)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val rootView = inflater.inflate(R.layout.pb_fr, container, false)

        recyclerView = rootView.pb_rv
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.itemAnimator = DefaultItemAnimator()
        recyclerView.isNestedScrollingEnabled = true

        dateTittle = rootView.pb_date_title
        dateTittle.text = mainVM.getDateOfRates().toString()
        dateTittle.paintFlags = dateTittle.paintFlags or Paint.UNDERLINE_TEXT_FLAG
        dateIcon = rootView.pb_date_iv

        return rootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dateTittle.setOnClickListener(this)
        dateIcon.setOnClickListener(this)

        mainVM.getDateOfRates().observe(this, Observer {
            onDateChange(it)
        })

        mainVM.getPbCurrentCashExchangeRates().observe(this, Observer{
            onDataChange(it)
        })

    }

    private fun onDateChange(it: Long) {
        pb_date_title.text = formatter.format(it).toString()
        pbRvAdapter.notifyDataSetChanged()
        onDataChange(mainVM.getPbCurrentCashExchangeRates().value!!)
    }

    private fun onDataChange(it: PbExchangeRatesResponse) {
        pbRvAdapter = PBListOfCurrenciesAdapter(it.listOfPbExchangeRates)
        recyclerView.adapter = pbRvAdapter
        pbRvAdapter.notifyDataSetChanged()
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH)
        val datePickerDialog = DatePickerDialog(
            context!!, this, year, month, dayOfMonth
        )
        datePickerDialog.show()
    }

}*//*


class MainViewModel: ViewModel() {

    private val exchangeRatesRepository: ExchangeRatesRepository = ExchangeRatesRepository.getInstance()

    private val dateOfRates: MutableLiveData<Long> by lazy {
        MutableLiveData<Long>()
    }

    private val pbExchangeRatesResponse: MutableLiveData<PbExchangeRatesResponse> = exchangeRatesRepository.getPbCurrentCashExchangeRates(getDateOfRatesForPbRequest())

    private val nbuExchangeRatesResponse: MutableLiveData<List<NbuExchangeRatesResponse>> = exchangeRatesRepository.getNbuCurrentExchangeRates(getDateOfRatesForNbuRequest())

    init {
        dateOfRates.value = Calendar.getInstance().timeInMillis
    }

    fun setDateOfRates(newDate: Long) {
        dateOfRates.value = newDate
    }

    fun getDateOfRates(): LiveData<Long> {
        return dateOfRates
    }

    private fun getDateOfRatesForPbRequest(): String {
        return DateFormat.format("dd.MM.yyyy", dateOfRates.value!!).toString()
    }

    private fun getDateOfRatesForNbuRequest(): String {
        return DateFormat.format("yyyyMMdd", dateOfRates.value!!).toString()
    }

}
*/
