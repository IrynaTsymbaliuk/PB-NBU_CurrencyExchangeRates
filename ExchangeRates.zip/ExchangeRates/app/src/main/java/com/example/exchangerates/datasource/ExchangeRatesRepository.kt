package com.example.exchangerates.datasource

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.exchangerates.model.NbuExchangeRatesResponse
import com.example.exchangerates.model.PbExchangeRatesResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ExchangeRatesRepository {

    private val pbExchangeRatesApi: ExchangeRatesApi = RetrofitService.pbService
    private val nbuExchangeRatesApi: ExchangeRatesApi = RetrofitService.nbuService

    companion object {
        const val TAG = "ExchangeRatesRepository"

        @Volatile
        private var instance: ExchangeRatesRepository? = null

        fun getInstance() =
            instance ?: synchronized(this) {
                instance
                    ?: ExchangeRatesRepository().also { instance = it }
            }
    }

    fun getPbCurrentCashExchangeRates(dateInPbFormat: String): MutableLiveData<PbExchangeRatesResponse> {
        val pbCurrentCashExchangeRates = MutableLiveData<PbExchangeRatesResponse>()
        pbExchangeRatesApi.getPBCurrentCashRates(dateInPbFormat).enqueue(object : Callback<PbExchangeRatesResponse> {
            override fun onResponse(
                call: Call<PbExchangeRatesResponse>,
                response: Response<PbExchangeRatesResponse>
            ) {
                if (!response.isSuccessful) {
                    Log.e(TAG, "Response ${response.code()}")
                } else {
                    pbCurrentCashExchangeRates.value = response.body()!!
                }
            }

            override fun onFailure(call: Call<PbExchangeRatesResponse>, t: Throwable) {
                Log.e(TAG, "Failure ${t.message}")
            }
        })
        return pbCurrentCashExchangeRates
    }

    fun getNbuCurrentExchangeRates(dateInNbuFormat: String): MutableLiveData<List<NbuExchangeRatesResponse>> {
        val nbuCurrentCashExchangeRates = MutableLiveData<List<NbuExchangeRatesResponse>>()
        nbuExchangeRatesApi.getNbuCurrentRates(dateInNbuFormat).enqueue(object : Callback<List<NbuExchangeRatesResponse>> {
            override fun onResponse(
                call: Call<List<NbuExchangeRatesResponse>>,
                response: Response<List<NbuExchangeRatesResponse>>
            ) {
                if (!response.isSuccessful) {
                    Log.e(TAG, "Response ${response.code()}")
                } else {
                    nbuCurrentCashExchangeRates.value = response.body()!!
                }
            }

            override fun onFailure(call: Call<List<NbuExchangeRatesResponse>>, t: Throwable) {
                Log.e(TAG, "Failure ${t.message}")
            }
        })
        return nbuCurrentCashExchangeRates
    }

}