package com.example.exchangerates.utils

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.exchangerates.R
import com.example.exchangerates.model.NbuExchangeRatesResponse
import com.example.exchangerates.model.PbExchangeRates
import kotlinx.android.synthetic.main.nbu_rv_item.view.*

class NBUListOfCurrenciesAdapter(private var listOfNbuExchangeRaterespons: List<NbuExchangeRatesResponse>) :
    RecyclerView.Adapter<NBUCurrenciesViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NBUCurrenciesViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val row = layoutInflater.inflate(R.layout.nbu_rv_item, parent, false)
        return NBUCurrenciesViewHolder(row)
    }

    override fun getItemCount(): Int {
        return listOfNbuExchangeRaterespons.size
    }

    override fun onBindViewHolder(holder: NBUCurrenciesViewHolder, position: Int) {
        if (position % 2 == 1) {
            holder.itemView.setBackgroundColor(Color.parseColor("#eef4f0"))
        } else {
            holder.itemView.setBackgroundColor(Color.parseColor("#fafafa"))
        }
        holder.nbuCurrency.text = listOfNbuExchangeRaterespons[position].currency.toString()
        holder.nbuSaleRate.text = listOfNbuExchangeRaterespons[position].saleRate.toString()
        holder.nbuUnits.text = listOfNbuExchangeRaterespons[position].currencyCodeL.toString()
    }

    private fun stringFormatOfSaleRate(arg: Float) = "$arg UAH"
    private fun stringFormatOfUnits(units: Int, currencyCodeL: String) = "$units $currencyCodeL"

    fun updateData(newListOfNbuExchangeRaterespons: List<NbuExchangeRatesResponse>) {
        listOfNbuExchangeRaterespons = newListOfNbuExchangeRaterespons
    }

}

class NBUCurrenciesViewHolder(view: View) : RecyclerView.ViewHolder(view) {

    val nbuCurrency: TextView = view.nbu_currency
    val nbuSaleRate: TextView = view.nbu_sale_rate
    val nbuUnits: TextView = view.nbu_units
}
