package com.example.exchangerates.model

import com.google.gson.annotations.SerializedName

data class NbuExchangeRatesResponse (
    @SerializedName("txt")
    val currency: String,
    @SerializedName("rate")
    val saleRate: Float,
    @SerializedName("cc")
    val currencyCodeL: String
)

data class PbExchangeRatesResponse(

    @SerializedName("dateOfRates")
    val date: String,
    @SerializedName("bank")
    val bank: String,
    @SerializedName("baseCurrency")
    val baseCurrency: Int,
    @SerializedName("baseCurrencyLit")
    val baseCurrencyLit: String,
    @SerializedName("exchangeRate")
    val listOfPbExchangeRates: List<PbExchangeRates>

)

data class PbExchangeRates(
    @SerializedName("currency")
    val currency: String,
    @SerializedName("saleRate")
    val saleRate: Double,
    @SerializedName("purchaseRate")
    val purchaseRate: Double
)