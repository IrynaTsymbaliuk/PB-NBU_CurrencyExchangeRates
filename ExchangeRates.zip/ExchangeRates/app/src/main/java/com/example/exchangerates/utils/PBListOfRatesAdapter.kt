package com.example.exchangerates.utils

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.exchangerates.R
import com.example.exchangerates.model.PbExchangeRates
import kotlinx.android.synthetic.main.pb_rv_item.view.*
import java.util.*

class PBListOfCurrenciesAdapter(private var listOfPBExchangeRates: List<PbExchangeRates>) :
    RecyclerView.Adapter<PBCurrenciesViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PBCurrenciesViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val row = layoutInflater.inflate(R.layout.pb_rv_item, parent, false)
        return PBCurrenciesViewHolder(row)
    }

    override fun getItemCount(): Int {
        return listOfPBExchangeRates.size
    }

    override fun onBindViewHolder(holder: PBCurrenciesViewHolder, position: Int) {
        holder.pbCurrency.text = listOfPBExchangeRates[position].currency
        holder.pbPurchaseRate.text = stringFormat(listOfPBExchangeRates[position].purchaseRate)
        holder.pbSaleRate.text = stringFormat(listOfPBExchangeRates[position].saleRate)
    }

    private fun stringFormat(args: Double) = String.format(Locale.ROOT, "%.03f", args)

    fun updateData(newListOfPBExchangeRates: List<PbExchangeRates>) {
        listOfPBExchangeRates = newListOfPBExchangeRates
    }

}

class PBCurrenciesViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    val pbCurrency: TextView = view.pb_currency
    val pbPurchaseRate: TextView = view.pb_purchase_rate
    val pbSaleRate: TextView = view.pb_sale_rate
}
