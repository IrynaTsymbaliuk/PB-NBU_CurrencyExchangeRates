package com.example.exchangerates.vm

import android.text.format.DateFormat
import androidx.lifecycle.*
import com.example.exchangerates.datasource.ExchangeRatesRepository
import com.example.exchangerates.model.NbuExchangeRatesResponse
import com.example.exchangerates.model.PbExchangeRatesResponse
import java.util.*

class MainVM : ViewModel() {

    private val dateOfRates = MutableLiveData<Long>()

    var pbExchangeRatesResponse = MutableLiveData<PbExchangeRatesResponse>()
    var nbuExchangeRatesResponse = MutableLiveData<List<NbuExchangeRatesResponse>>()
    private val exchangeRatesRepository: ExchangeRatesRepository = ExchangeRatesRepository.getInstance()

    init {
        Transformations.switchMap(dateOfRates) {
            exchangeRatesRepository.getPbCurrentCashExchangeRates(getDateOfRatesForPbRequest(it))
        }.observeForever {
            pbExchangeRatesResponse.value = it
        }
        Transformations.switchMap(dateOfRates) {
            exchangeRatesRepository.getNbuCurrentExchangeRates(getDateOfRatesForNbuRequest(it))
        }.observeForever {
            nbuExchangeRatesResponse.value = it
        }
        dateOfRates.value = Calendar.getInstance().timeInMillis
    }

    fun setDateOfRates(newDate: Long) {
        dateOfRates.value = newDate
    }

    fun getDateOfRates(): LiveData<Long> {
        return dateOfRates
    }

    private fun getDateOfRatesForPbRequest(date: Long): String {
        return DateFormat.format("dd.MM.yyyy", date).toString()
    }

    private fun getDateOfRatesForNbuRequest(date: Long): String {
        return DateFormat.format("yyyyMMdd", date).toString()
    }

    /*fun getPbExchangeRatesResponse(): MediatorLiveData<PbExchangeRatesResponse> {
        return pbExchangeRatesResponse
    }

    fun getNbuExchangeRatesResponse(): MediatorLiveData<List<NbuExchangeRatesResponse>> {
        return nbuExchangeRatesResponse
    }*/

}