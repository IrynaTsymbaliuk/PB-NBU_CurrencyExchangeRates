package com.example.exchangerates.datasource

import android.database.Observable
import com.example.exchangerates.model.NbuExchangeRatesResponse
import com.example.exchangerates.model.PbExchangeRatesResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query
import android.provider.Telephony.Mms.Rate



interface ExchangeRatesApi {

    /*@GET("exchange_rates?json&")
    fun getPBCurrentCashRates(@Query("dateOfRates") date:String) : Call<PbExchangeRatesResponse>
*/

    @GET("p24api/exchange_rates?json")
    fun getPBCurrentCashRates(@Query("date") date:String): Call<PbExchangeRatesResponse>


    @GET("statdirectory/exchange?json")
    fun getNbuCurrentRates(@Query("date") date:String): Call<List<NbuExchangeRatesResponse>>

}

